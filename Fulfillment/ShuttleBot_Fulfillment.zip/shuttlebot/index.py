from flask import Flask, request, jsonify, render_template
import datetime
import pytz
import calendar
import os
import dialogflow_v2 as dialogflow
import requests
import json

app = Flask(__name__)

## Route a dictionary containing tuples as the key.
## Each tuple refers a unique combination of property, pickup point, weekdaytype. 
## Based on the tuple combination, there will be a list containing the leaving time.
## This list is returned by the function
## The dictionary below represents the hypothetical bus schedule from 
routes = {
            ("Goodlife Club", "Clubhouse", "Weekday"): ["1:00PM", "3:00PM", "5:00PM", "7:00PM"], 
            ("Goodlife Club", "Pasir Ris Mrt", "Weekday"): ["1:30PM", "3:30PM", "5:30PM", "7:30PM"], 
            ("Goodlife Club", "Clubhouse", "Weekend"): ["1:00PM", "2:00PM","3:00PM", "4:00PM", "5:00PM", "6:00PM","7:00PM"], 
            ("Goodlife Club", "Clubhouse", "Weekend"): ["1:30PM", "2:30PM","3:30PM", "4:30PM", "5:30PM", "6:30PM","7:30PM"], 
            ("AI Hub Park", "Clementi MRT", "Weekday"): ["8:00AM", "8:30AM", "9:00AM"],
            ("AI Hub Park", "Clementi MRT", "Weekend"): ["No services"],
            ("AI Hub Park", "Block A", "Weekday"): ["5:00PM", "6:00PM", "7:00PM"],
            ("AI Hub Park", "Block B", "Weekday"): ["5:15PM", "6:15PM", "7:15PM"],
            ("AI Hub Park", "Block A", "Weekend"): ["No services"],
            ("AI Hub Park", "Block B", "Weekend"): ["No services"],
}  

# Get list of property names from routes dictionary 
properties = list(set([key[0] for key, value in routes.items()]))

# Image web urls for properties and pickup points
imageurls = {
    "Goodlife Club": "http://www.clubcorp.com/var/ezflow_site/storage/images/media/clubs/monarch-country-club-media/images/redesign-website-images/monarch_main_clubhouse_1/12985662-1-eng-US/Monarch_Main_Clubhouse_1.jpg",
    "AI Hub Park": "https://upload.wikimedia.org/wikipedia/commons/8/80/Riviera_Country_Club%2C_Golf_Course_in_Pacific_Palisades%2C_California_%28168828797%29.jpg",
    "Pasir Ris Mrt": "https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/PasirRisMRTStation.JPG/300px-PasirRisMRTStation.JPG",
    "Clubhouse": "https://seeklogo.com/images/C/Club_House-logo-0C7D85B9B8-seeklogo.com.png",
    "Clementi MRT": "https://www.streetdirectory.com/stock_images/travel/simg_show/12688207840563/1/clementi_mrt_ew23_entranceexit_a/",
    "Block A": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuBVK2Pm2nUGHpoVO4DgVVFrF7zAx1F4gmqYQG21fUkFOgXxkT",
    "Block B" : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRS0V7clYRq__4QwqOf88_ZIzREjSPjbqWarSiScF-PuBKvCqQ5"
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.get_json(silent=True)   # get the incoming JSON structure
    action = data['queryResult']['action'] # get the action name associated with the matched intent

    if( action == 'input.welcome'):
        return welcome(data)
    elif (action == 'input.unknown'):
        return fallback(data)
    elif (action == 'test_connection'):
        return test_connection(data)
    elif(action == 'get_nextshuttle'):
        return get_nextshuttle(data)
    elif(action == 'get_pickuppoints'):
        return get_pickuppoints(data)
    elif(action == 'get_propertyschedule'):
        return get_property_schedule(data)

# webhook for Default.Welcome intent
def welcome(data):
    
    welcome_msg = "🏳️‍🌈 Hi, I am shuttlebot, your friendly shuttle service bot. I can help you with the following services. Your choice, please. 🏳️‍🌈"
    available_services = ["Get Schedule", "Get Pickup Points", "Get Next Shuttle"]
    imageurl = "https://a.imge.to/2019/07/07/IcEkV.jpg"

    reply = build_Card_Msg(welcome_msg, "", imageurl, available_services)

    return jsonify(reply)

# webhook for Default.Fallback intent
def fallback(data):
    
    fallback_msg = "🏳️‍🌈 Oops, I did not understand. I can help you with the following services. Your choice, please. 🏳️‍🌈"
    available_services = ["Get Schedule", "Get Pickup Points", "Get Next Shuttle"]
    imageurl = "https://a.imge.to/2019/07/07/IcEkV.jpg"

    reply = build_Card_Msg(fallback_msg, "", imageurl, available_services)

    return jsonify(reply)

# webhook for Default.ConnectionTest intent
def test_connection(data):
    reply = {}
    reply["fulfillmentText"] = "👍👍ShuttleMasterBot Connection Test Successful!"

    return jsonify(reply)

# webhook for Get.NextShuttle intent
def get_nextshuttle(data):
    
    property = data['queryResult']['parameters']['property']
    pickUpPt = data['queryResult']['parameters']['pickup_point']
    day_type, currtime = __get_daytype()

    gotProperty = len(property) > 0
    gotpickUpPt = len(pickUpPt) > 0

    # Get pickup points for property
    pickuppoints = __get_pickuppoints(property)

    # Slot filling for Get.NextShuttle intent 
    if ((not gotProperty) or (property not in properties)):
        reply = build_QuickReply_Msg("Please select a property", properties)
    elif ((not gotpickUpPt) or (pickUpPt not in pickuppoints)):
        reply = build_QuickReply_Msg("Please select a pickup point", pickuppoints)
    else:
        # Get shuttle timings from routes dictionary
        timelist = __get_shuttleschedule(property, pickUpPt, day_type)

        if(timelist[0] not in ["There is no route found", "No services"]):
            filtered_timelist = []
            for pickuptime in timelist:
                # Add timing to list of shuttle timings if timing has not passed for current day,  
                dt_pickuptime = datetime.datetime.strptime(pickuptime, '%I:%M%p').time()
                if(dt_pickuptime > currtime):
                    filtered_timelist.append(pickuptime)
            
            header = "🚌 %s Schedule for %s at %s is :" %(day_type, property, pickUpPt)

            # Send appropriate message if no more shuttle timings for current day
            if(len(filtered_timelist) == 0):
                schedulelist = "There are no more pickups for today"
            else:
                schedulelist = ", ".join(pickuptime for pickuptime in filtered_timelist)

            reply = build_Card_Msg(header, schedulelist, imageurls[property], [])
        else:
            reply = build_Multiline_Msg("❌⚠️⚠️⚠️❌", "No schedule found")
        
    return jsonify(reply)

# Gets shuttle timings for specified property/pickup/daytype (weekday/weekend) combination
def __get_shuttleschedule(property, pickup_point, day_type):

    result = routes.get( (property  ,  pickup_point , day_type ), ["There is no route found"])       

    return result

# webhook for Get.PickupPoints intent
def get_pickuppoints(data):
    
    property = data['queryResult']['parameters']['property']

    header = "🚏 Pick up points for %s are :" %(property)

    gotProperty = len(property) > 0

    # Slot filling for Get.PickupPoints intent 
    if ((not gotProperty) or (property not in properties)):
        reply = build_QuickReply_Msg("Please select a property", properties)
    else:
        # Get pickup points for specified property name
        pickuppointlist = __get_pickuppoints(property)
        pickuppoints = ", ".join(pickuppoint for pickuppoint in pickuppointlist)

        if(len(pickuppointlist) != 0):
            reply = build_Multiline_Msg(header, pickuppoints)
        else:
            reply = build_Multiline_Msg("❌⚠️⚠️⚠️❌", "No pickup points found")

    return jsonify(reply)    

#Gets list of pickup points for specified property 
def __get_pickuppoints(property):
    pickuppoints = list(set([key[1] for key, value in routes.items() if property == key[0]]))

    return pickuppoints

# Find daytype based on the day of week (e.g. weekend or weekday)
def __get_daytype():	
    ### gets the current time
    now = datetime.datetime.now(pytz.timezone('Asia/Singapore'))
    ### 0 - 4 (weekday), 5-6 (weekend)
    dayofweek = now.weekday()
    ### Gets the current time     
    currtime = now.time()
    
    if (dayofweek > 4 ):
        daytype = "Weekend"
    else:
        daytype = "Weekday"
        
    return daytype, currtime

# webhook for Get.PropertySchedule intent
def get_property_schedule(data):
    
    property = data['queryResult']['parameters']['property']

    gotProperty = len(property) > 0

    # Slot filling for Get.PropertySchedule intent
    if ((not gotProperty) or (property not in properties)):
        reply = build_QuickReply_Msg("Please select a property", properties)
    else:
        # Gets list of pickup points for specified property
        pickuppoints = __get_pickuppoints(property)
        print("Pickup points:", pickuppoints)
        schedule = {}
        scheduleD = {}

        # Builds dictionary of shuttle timings by pickup point/daytype combination
        if(len(pickuppoints) != 0): # check if property input is valid
            for pickuppoint in pickuppoints:
                scheduleD[pickuppoint] = {}
                for daytype in ["Weekday", "Weekend"]:
                    scheduleD[pickuppoint][daytype] = __get_shuttleschedule(property, pickuppoint, daytype)
            schedule[property] = scheduleD

            reply = build_MultiCard_Msg(schedule)
        else:
            reply = build_Multiline_Msg("❌⚠️⚠️⚠️❌", "No pickup points found")
        
    return jsonify(reply) 

# Builds single line text message reply 
def build_Singleline_Msg(content):
    reply = {
        "fulfillmentText": " " ,
        "fulfillmentMessages" : [
            {
              "text" : {
                  "text" : [content]
              }
              ,
              "platform": "TELEGRAM"    
            },
            {
              "text" : {
                  "text" : [content]
              }   
            }
        ]
    }

    return reply

# Builds multi-line text message reply 
def build_Multiline_Msg(header, content):
    lines = [header, content]

    msgs = []
    for line in lines:
        response_telegram = {'text': {'text': [line]}, "platform": "TELEGRAM" }
        response_default = {'text': {'text': [line]} }
        msgs.append(response_telegram)
        msgs.append(response_default)
        
    reply = {}
    reply["fulfillmentText"] = " "
    reply["fulfillmentMessages"] = msgs    

    return reply

# Builds quick reply message reply 
def build_QuickReply_Msg(title, choices):
    reply = {}
    reply["fulfillmentText"] = " "  
    reply["fulfillmentMessages"] =  [
         { 
          "quickReplies" : {
                 "title" : title,
                 "quickReplies" : choices
          }
         ,
          "platform" : "TELEGRAM"
         },
         { 
          "quickReplies" : {
                 "title" : title,
                 "quickReplies" : choices
          }
         }
    ]
    return reply

# Builds card message reply 
def build_Card_Msg(title, subtitle, imageurl, buttons):

    choices = []
    if(len(buttons) != 0):
        for button in buttons:
            choice = {"text": button}
            choices.append(choice)
    else:
        choices = []

    reply = {}
    reply["fulfillmentText"] = " "  
    reply["fulfillmentMessages"] =  [
      {
        "card": {
             "title": title,
             "subtitle": subtitle,
             "imageUri": imageurl,
             "buttons": choices
        },
        "platform": "TELEGRAM"
      },
      {
        "card": {
             "title": title,
             "subtitle": subtitle,
             "imageUri": imageurl,
             "buttons": choices
        }
      }
    ]
    return reply

# Builds custom multiple card message reply
def build_MultiCard_Msg(schedule):
    cards = []

    property = next(iter(schedule))

    for propertyname, scheduledetails in schedule.items():
        for pickuppoint, daytypedetails in scheduledetails.items():
            for daytype, daytypeschedule in daytypedetails.items():
                shuttle_times = []
                for shuttle_time in daytypeschedule:
                    #shuttle_times.append({"text": shuttle_time})
                    shuttle_times.append(shuttle_time)

                shuttleschedule = {"text": "  ".join(shuttle_time for shuttle_time in shuttle_times),
                                   "postback": ""
                                }

                if(shuttleschedule["text"] not in ["There is no route found", "No services"] ):
                    card_telegram = {
                        "card": {
                            "title": pickuppoint,
                            "subtitle": daytype,
                            "imageUri": imageurls[pickuppoint],
                            "buttons": [shuttleschedule]
                        },
                        "platform": "TELEGRAM"
                    }
                    card_default = {
                        "card": {
                            "title": pickuppoint,
                            "subtitle": daytype,
                            "imageUri": imageurls[pickuppoint],
                            "buttons": [shuttleschedule]
                        }
                    }
                    cards.append(card_telegram)
                    cards.append(card_default)

    reply = {}
    reply["fulfillmentText"] = " "  
    reply["fulfillmentMessages"] = cards

    return reply

# Builds custom inline keyboard message reply
def build_customInlineKB_Msg(title, choices):
    reply = {}
    reply["fulfillmentText"] = ""
    reply["fulfillmentMessages"] = []
      
    msg_object = {}
    msg_object['platform'] = "TELEGRAM"

    msg_object["payload"] = {}
    msg_object["payload"]['telegram'] = {}
    msg_object["payload"]['telegram']['text'] = title
    msg_object["payload"]['telegram']['reply_markup'] = {}
    msg_object["payload"]['telegram']['reply_markup']['inline_keyboard'] = []
        
    tg_keyboard_row = []

    for choice in choices:
        print(choice)
        tg_keyboard_row.append({"text" : choice, "callback_data": choice})
    
    msg_object["payload"]["telegram"]["reply_markup"]["inline_keyboard"].append(tg_keyboard_row)
	
    reply["fulfillmentMessages"].append(msg_object)

    return reply

if __name__ == "__main__":
    app.run()